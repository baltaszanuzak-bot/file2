// ===== PORTFOLIO MODULES / ОСНОВНАЯ ЛОГИКА =====

/**
 * Scroll Animations
 * Observe sections and add 'visible' class when they enter viewport
 */
function initScrollAnimations() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
      }
    });
  }, { threshold: 0.1 });

  document.querySelectorAll('.section-animate').forEach(el => observer.observe(el));
}

/**
 * Active Navigation on Scroll
 * Highlight nav link based on current section
 */
function initActiveNavigation() {
  const sections = document.querySelectorAll('section');
  const navLinks = document.querySelectorAll('.nav-link');

  window.addEventListener('scroll', () => {
    let current = '';
    sections.forEach(section => {
      const sectionTop = section.offsetTop - 100;
      if (window.scrollY >= sectionTop) {
        current = section.getAttribute('id');
      }
    });

    navLinks.forEach(link => {
      link.style.color = '';
      link.style.background = '';
      if (link.getAttribute('href') === '#' + current) {
        link.style.color = 'var(--accent)';
        link.style.background = 'rgba(249,115,22,0.08)';
      }
    });
  });
}

/**
 * Contact Function
 * Open Telegram link in new window
 */
function contact() {
  window.open('https://t.me/zhanuzak', '_blank');
}

/**
 * Theme Toggle
 * Switch between light and dark themes
 */
function toggleTheme() {
  const body = document.body;
  const btn = document.getElementById('themeBtn');
  body.classList.toggle('light');
  const isLight = body.classList.contains('light');
  btn.innerHTML = isLight
    ? '<i class="fas fa-moon"></i> <span>Тёмная тема</span>'
    : '<i class="fas fa-sun"></i> <span>Светлая тема</span>';
  localStorage.setItem('theme', isLight ? 'light' : 'dark');
}

/**
 * Load Saved Theme
 * Restore theme from localStorage
 */
function loadSavedTheme() {
  const saved = localStorage.getItem('theme');
  if (saved === 'light') {
    document.body.classList.add('light');
    const btn = document.getElementById('themeBtn');
    if (btn) btn.innerHTML = '<i class="fas fa-moon"></i> <span>Тёмная тема</span>';
  }
}

/**
 * Initialize All Modules on DOM Ready
 */
function initPortfolio() {
  loadSavedTheme();
  initScrollAnimations();
  initActiveNavigation();
  
  // Make first section visible immediately
  document.querySelector('.section-animate')?.classList.add('visible');
}

// Start when DOM is loaded
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initPortfolio);
} else {
  initPortfolio();
}
