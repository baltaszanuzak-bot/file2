# 🏆 Best Practices - Лучшие практики

## 📋 Правила разработки ProfiSpace

---

## 🎯 1. СТРУКТУРА ФАЙЛОВ

### HTML (Разметка - чистая!)
```html
✅ ПРАВИЛЬНО:
<section id="projects" class="section-animate">
  <p class="section-tag" data-t="secProjects">Проекты</p>
  <div class="cards">
    <!-- Контент -->
  </div>
</section>

❌ НЕПРАВИЛЬНО:
<section style="opacity: 0; transform: translateY(20px);">
  <p style="font-size: 0.7rem; color: #f97316;">Проекты</p>
  <div onclick="alert('hello')">
```

**Правило:** HTML содержит только разметку, стили в CSS, логика в JS

---

## 🎨 2. CSS (Стили - модульные!)

### Правильная организация
```css
✅ ПРАВИЛЬНО:

/* ===== SECTION ===== */
.section-name {
  /* базовые стили */
}

.section-name-item {
  /* стили элементов */
}

.section-name-item:hover {
  /* интерактивность */
}

@media (max-width: 768px) {
  .section-name {
    /* мобильные стили */
  }
}

❌ НЕПРАВИЛЬНО:

.s1, .s2, .s3 { color: #e2e8f0; }
.i { padding: 10px; }
#unique-id { background: red; }
/* все в одну кучу */
```

**Правило:** Группируйте стили по компонентам, используйте семантические имена

---

### Переменные CSS
```css
✅ ПРАВИЛЬНО:

:root {
  --accent: #f97316;
  --text: #e2e8f0;
}

.button {
  background: var(--accent);
  color: var(--text);
}

body.light {
  --accent: #f97316;
  --text: #0f172a;
}

❌ НЕПРАВИЛЬНО:

.button {
  background: #f97316;
  color: #e2e8f0;
}

body.light .button {
  background: #f97316;
  color: #0f172a;
}
```

**Правило:** Все цвета через CSS переменные!

---

## 🧠 3. JAVASCRIPT (Логика - модульная!)

### Правильная структура
```javascript
✅ ПРАВИЛЬНО:

// 1. Основная функция
function initScrollAnimations() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
      }
    });
  });
  
  document.querySelectorAll('.section-animate').forEach(el => 
    observer.observe(el)
  );
}

// 2. Инициализация
function initPortfolio() {
  loadSavedTheme();
  initScrollAnimations();
  initActiveNavigation();
}

// 3. Запуск
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initPortfolio);
} else {
  initPortfolio();
}

❌ НЕПРАВИЛЬНО:

// Всё в одной функции
function init() {
  // 200 строк кода
  // querySelector...
  // addEventListener...
  // setTimeout...
  // ...
}

// Используется сразу при загрузке
init();
```

**Правило:** Разбивайте на маленькие функции, инициализируйте в конце

---

### Проверка элементов
```javascript
✅ ПРАВИЛЬНО:

const element = document.querySelector('.element');
if (element) {
  element.addEventListener('click', handleClick);
}

// Или с опциональной цепочкой
document.querySelector('.element')?.addEventListener('click', handleClick);

❌ НЕПРАВИЛЬНО:

document.querySelector('.element').addEventListener('click', handleClick);
// Ошибка если элемента нет!

// Общие селекторы
document.querySelectorAll('div').forEach(el => {
  // Обработка ВСЕХ div'ов!
});
```

**Правило:** Всегда проверяйте существование элемента

---

### Обработка событий
```javascript
✅ ПРАВИЛЬНО:

function handleClick(event) {
  event.preventDefault();
  console.log('Clicked:', this);
  // Ваша логика
}

// В HTML
<button onclick="contact()">Contact</button>

// В JS
function contact() {
  window.open('https://t.me/username', '_blank');
}

❌ НЕПРАВИЛЬНО:

// Встроенные логика в onclick
<button onclick="window.open(...); alert(...); fetch(...);">

// Множественные слушатели без очистки
document.addEventListener('click', handler);
document.addEventListener('click', handler);
document.addEventListener('click', handler);
// Memory leak!
```

**Правило:** Функции отдельно, HTML чистый

---

## 🌍 4. ПЕРЕВОДЫ

### Правильное использование
```html
✅ ПРАВИЛЬНО:

<!-- Динамическое изменение -->
<h1 id="title"></h1>
<script>
  // В translations.js
  document.getElementById('title').innerHTML = translations['ru']['title'];
</script>

<!-- Автоматическое -->
<p class="section-tag" data-t="secProjects">Проекты</p>
<span data-t="btnCV">Скачать CV</span>

❌ НЕПРАВИЛЬНО:

<!-- Хардкод переводов в HTML -->
<h1>Привет, я Zhanuzak 👋</h1>

<!-- Переводы в JS без структуры -->
const text_ru = "...";
const text_en = "...";
```

**Правило:** Используйте `data-t` атрибут, все переводы в `translations.js`

---

## 🎭 4. ТЕМЫ (Light/Dark)

### Правильная реализация
```javascript
✅ ПРАВИЛЬНО:

function toggleTheme() {
  document.body.classList.toggle('light');
  const isLight = document.body.classList.contains('light');
  localStorage.setItem('theme', isLight ? 'light' : 'dark');
}

function loadSavedTheme() {
  const saved = localStorage.getItem('theme');
  if (saved === 'light') {
    document.body.classList.add('light');
  }
}

// CSS
:root { --text: #e2e8f0; }
body.light { --text: #0f172a; }

❌ НЕПРАВИЛЬНО:

function toggleTheme() {
  if (isDark) {
    document.body.style.backgroundColor = '#f1f5f9';
    document.body.style.color = '#0f172a';
    // ... 50 других style.
  } else {
    document.body.style.backgroundColor = '#0f172a';
    // ...
  }
}
```

**Правило:** Используйте CSS классы, не встроенные стили

---

## 🔍 5. ПРОИЗВОДИТЕЛЬНОСТЬ

### Оптимизация скриптов
```javascript
✅ ПРАВИЛЬНО:

// Используйте event delegation
document.addEventListener('click', (e) => {
  if (e.target.matches('.btn')) {
    handleButtonClick(e.target);
  }
});

// Кешируйте selectors
const buttons = document.querySelectorAll('.btn');
buttons.forEach(btn => {
  btn.addEventListener('click', handleClick);
});

// Используйте requestAnimationFrame
function animate() {
  // обновление
  requestAnimationFrame(animate);
}

❌ НЕПРАВИЛЬНО:

// Множественные селекты
document.querySelectorAll('.btn').forEach(btn => {
  btn.addEventListener('click', () => {
    // querySelectAll ещё раз
    document.querySelectorAll('.card').forEach(card => {
      // ...
    });
  });
});

// Прямые манипуляции DOM в цикле
for (let i = 0; i < 1000; i++) {
  document.body.innerHTML += '<div>Item ' + i + '</div>';
  // Перекомпиляция DOM каждый раз!
}
```

**Правило:** Минимизируйте DOM операции

---

## 📝 6. КОММЕНТАРИИ И ДОКУМЕНТАЦИЯ

### Правильные комментарии
```javascript
✅ ПРАВИЛЬНО:

/**
 * Инициализация скролл-анимаций
 * Наблюдает за элементами с классом section-animate
 * Добавляет класс visible когда они видны в viewport
 */
function initScrollAnimations() {
  // ...
}

// Раздел модуля
// ===== SCROLL ANIMATIONS =====

// Важные замечания
// TODO: Оптимизировать для мобильных
// NOTE: Работает только в современных браузерах

❌ НЕПРАВИЛЬНО:

// Очищаем массив
arr = [];

// если верно
if (x) {
  // делаем что-то
}

// Нет комментариев вообще
function foo() {
  return bar.map(x => x.y).filter(z => z > 5);
}
```

**Правило:** Комментируйте ЧТО и ПОЧЕМУ, не ЧТО ДЕЛАЕТ КОД

---

## 🧪 7. ТЕСТИРОВАНИЕ

### Проверка функциональности
```javascript
✅ ПРАВИЛЬНО:

// Проверить в браузере
1. Open index.html
2. Проверить анимацию приветствия
3. Нажать кнопку
4. Проверить загрузку портфолио
5. Переключить язык (RU/EN/KZ)
6. Переключить тему (Dark/Light)
7. Проверить скролл-навигацию
8. Проверить ResponsiveDesign (F12)
9. Консоль (F12) - ошибок нет

❌ НЕПРАВИЛЬНО:

// Отправить в production без проверки
// "Авось работать будет"
```

**Правило:** Тестируйте на разных браузерах, устройствах, языках

---

## 🚀 8. ДОБАВЛЕНИЕ НОВОГО ФУНКЦИОНАЛА

### Пример: Добавить новую секцию

**Шаг 1: HTML**
```html
<section id="new-feature" class="section-animate">
  <p class="section-tag" data-t="secNew">Новая секция</p>
  <div class="new-feature-grid">
    <!-- контент -->
  </div>
</section>
```

**Шаг 2: CSS (portfolio.css)**
```css
/* ================================================ */
/* NEW FEATURE SECTION / НОВАЯ СЕКЦИЯ              */
/* ================================================ */

.new-feature-grid {
  display: grid;
  gap: 16px;
}

@media (max-width: 768px) {
  .new-feature-grid {
    grid-template-columns: 1fr;
  }
}
```

**Шаг 3: Переводы (translations.js)**
```javascript
translations.ru.secNew = 'Новая секция';
translations.ru.textNew = 'Описание';

translations.en.secNew = 'New Section';
translations.en.textNew = 'Description';
```

**Шаг 4: Логика (modules.js)**
```javascript
function initNewFeature() {
  const section = document.querySelector('#new-feature');
  if (section) {
    // ваша логика
  }
}

function initPortfolio() {
  // ...
  initNewFeature();
}
```

**Правило:** Следуйте существующему паттерну проекта

---

## ⚠️ 9. ЧАСТЫЕ ОШИБКИ

### Что НЕ делать

```javascript
❌ Не используйте global переменные
var globalVar = 'bad';

❌ Не используйте document.write()
document.write('<h1>Hello</h1>');

❌ Не используйте eval()
eval('dangerous code here');

❌ Не забывайте точки с запятой
let x = 5  // Может сломать код
let y = 6

❌ Не используйте setTimeout без причины
setTimeout(() => {
  doSomething();
}, 1000);

✅ Вместо этого используйте:
document.addEventListener('load', doSomething);
```

---

## 🎓 10. РЕСУРСЫ

### Дополнительное чтение
- MDN Web Docs (https://developer.mozilla.org)
- CSS Tricks (https://css-tricks.com)
- JavaScript.info (https://javascript.info)
- Google DevTools Guide

### Инструменты
- VS Code + Extensions
- Browser DevTools (F12)
- Lighthouse (Performance audit)

---

## ✅ Чек-лист перед commit

```
☐ HTML валиден (нет синтаксических ошибок)
☐ CSS организован по секциям
☐ JavaScript не имеет console errors
☐ Используются CSS переменные для цветов
☐ Нет встроенных стилей в HTML
☐ Нет встроенных скриптов в HTML
☐ Все переводы в translations.js
☐ Коммент код задокументирован
☐ Функции имеют descriptive names
☐ Адаптивный дизайн протестирован
☐ Обе темы (dark/light) работают
☐ Все языки работают
```

---

**Следуйте этим практикам и ваш код будет чистым, понятным и профессиональным!** ✨
