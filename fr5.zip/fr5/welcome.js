// ===== WELCOME SCREEN ANIMATION & LOGIC =====

// Initialize canvas background animation
const canvas = document.getElementById('bg-canvas');
const ctx = canvas.getContext('2d');
let W, H, dots = [];

function resize() {
  W = canvas.width = innerWidth;
  H = canvas.height = innerHeight;
}

function initDots() {
  dots = [];
  for (let i = 0; i < 60; i++) {
    dots.push({
      x: Math.random() * W,
      y: Math.random() * H,
      r: Math.random() * 1.5 + 0.3,
      vx: (Math.random() - 0.5) * 0.3,
      vy: (Math.random() - 0.5) * 0.3,
      opacity: Math.random() * 0.4 + 0.1
    });
  }
}

function draw() {
  ctx.clearRect(0, 0, W, H);
  dots.forEach(d => {
    d.x += d.vx;
    d.y += d.vy;
    if (d.x < 0) d.x = W;
    if (d.x > W) d.x = 0;
    if (d.y < 0) d.y = H;
    if (d.y > H) d.y = 0;
    ctx.beginPath();
    ctx.arc(d.x, d.y, d.r, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(249,115,22,${d.opacity})`;
    ctx.fill();
  });

  // Lines between nearby dots
  for (let i = 0; i < dots.length; i++) {
    for (let j = i + 1; j < dots.length; j++) {
      const dx = dots[i].x - dots[j].x;
      const dy = dots[i].y - dots[j].y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist < 120) {
        ctx.beginPath();
        ctx.moveTo(dots[i].x, dots[i].y);
        ctx.lineTo(dots[j].x, dots[j].y);
        ctx.strokeStyle = `rgba(249,115,22,${0.06 * (1 - dist / 120)})`;
        ctx.lineWidth = 0.5;
        ctx.stroke();
      }
    }
  }
  requestAnimationFrame(draw);
}

// Initialize animation on page load
resize();
initDots();
draw();
window.addEventListener('resize', () => {
  resize();
  initDots();
});

// Enter site function
function enterSite() {
  document.getElementById('welcome').classList.add('hide');
  document.body.style.overflow = 'auto';
  setTimeout(() => {
    document.getElementById('welcome').style.display = 'none';
  }, 900);
}
