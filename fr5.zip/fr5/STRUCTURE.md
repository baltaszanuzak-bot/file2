# 📂 Архитектура ProfiSpace Portfolio

## 🎯 Обзор структуры

Проект разделён на **логические модули** для лучшей организации кода:

```
index.html          ← Точка входа (Экран приветствия)
  ├─ welcome.css       ← Стили приветствия
  └─ welcome.js        ← Логика анимаций (Canvas)
     ↓
portfolio.html      ← Основная страница
  ├─ portfolio.css     ← Стили портфолио
  ├─ translations.js   ← Переводы (RU/EN/KZ)
  └─ modules.js        ← Логика (Темы, скролл, анимации)
```

## 📋 Каждый файл отвечает за:

### **index.html** (Приветственный экран)
- Минималистичный HTML с canvas элементом
- Подключает: `welcome.css`, `welcome.js`, Font Awesome

### **welcome.css** (Стили приветствия)
- CSS переменные для тёмной/светлой темы
- Стили canvas фона
- Анимации входа (fadeUp, pulse, spin)
- Полностью отделён от основного сайта

### **welcome.js** (Логика приветствия)
- Инициализация Canvas
- Генерация и анимация частиц
- Функция `enterSite()` для входа на основной сайт

---

### **portfolio.html** (Основной сайт)
- Структурированная разметка
- Использует `data-t` атрибуты для автоперевода
- Подключает 2 JS файла (в конце body)

### **portfolio.css** (Стили портфолио)
- **800+ строк** организованных по секциям:
  1. Reset & Variables (Colors)
  2. Layout & Sidebar
  3. Profile Info & Navigation
  4. Content Area
  5. About Section
  6. Services Grid
  7. Skills List
  8. Projects Cards
  9. Reviews Section
  10. Contact Block
  11. Animations
  12. Mobile Responsive

- **Поддержка двух тем:**
  ```css
  :root { --bg: #0f172a; /* Dark */ }
  body.light { --bg: #f1f5f9; /* Light */ }
  ```

### **translations.js** (Переводы)
- Словарь на 3 языках: `ru`, `en`, `kz`
- Функция `setLang(lang)` для смены языка
- Автоматически обновляет все элементы с `data-t` атрибутом
- ~250 строк перевод контента

### **modules.js** (Основная логика)
- 6 основных функций:
  1. `initScrollAnimations()` - Появление секций
  2. `initActiveNavigation()` - Подсветка активного пункта меню
  3. `contact()` - Открытие Telegram
  4. `toggleTheme()` - Переключение темы
  5. `loadSavedTheme()` - Загрузка сохранённой темы
  6. `initPortfolio()` - Инициализация всех модулей

---

## 🔄 Поток данных

### При загрузке сайта:
```
index.html (загружается)
  ↓
welcome.js (canvas анимация запускается)
  ↓
На кнопку "Добро пожаловать"
  ↓
portfolio.html (загружается в iframe)
  ↓
translations.js (инициализация переводов)
modules.js (инициализация функций)
  ↓
Сайт готов к использованию
```

### При смене языка:
```
Клик на кнопку (RU/EN/KZ)
  ↓
setLang(lang) в translations.js
  ↓
Обновление всех элементов с data-t="key"
  ↓
Страница переводится на выбранный язык
```

### При переключении темы:
```
Клик на "Светлая тема"
  ↓
toggleTheme() в modules.js
  ↓
body.classList.toggle('light')
  ↓
CSS переменные меняют значения
  ↓
Весь сайт перекрашивается
  ↓
localStorage.setItem('theme', value)
  ↓
При следующем входе тема загружается
```

---

## 💾 Хранение данных

### localStorage
- **Ключ:** `theme`
- **Значения:** `'dark'` или `'light'`
- **Загружается:** При инициализации modules.js

---

## 🎨 CSS Переменные

### Тёмная тема (default)
```css
--bg: #0f172a          (Фон страницы)
--surface: #0a1120     (Фон боковой панели)
--border: #1e293b      (Границы, разделители)
--accent: #f97316      (Оранжевый - основной цвет)
--text: #e2e8f0        (Основной текст)
--muted: #64748b       (Вторичный текст)
--card: #0a1120        (Фон карточек)
--green: #10b981       (Зелёный - статусы)
--blue: #3b82f6        (Синий - акценты)
--subtext: #94a3b8     (Тусклый текст)
```

### Светлая тема
```css
--bg: #f1f5f9          (Светлый фон)
--surface: #ffffff     (Белый)
--text: #0f172a        (Тёмный текст)
... остальное адаптировано
```

---

## 📱 Адаптивность

### Точка разрыва: 768px
```css
@media (max-width: 768px) {
  .app { flex-direction: column; }
  .sidebar { width: 100%; position: static; }
}
```

---

## 🚀 Инициализация (Порядок выполнения)

```javascript
// 1. Загрузка modules.js
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initPortfolio);
} else {
  initPortfolio();
}

// 2. Функция инициализации
function initPortfolio() {
  loadSavedTheme();           // Загрузить сохранённую тему
  initScrollAnimations();     // Подписать на скролл-события
  initActiveNavigation();     // Подсветка активного меню
  // Первая секция сразу видима
  document.querySelector('.section-animate')?.classList.add('visible');
}
```

---

## 🔧 Расширение функционала

### Добавить новый перевод:
1. Откройте `translations.js`
2. Добавьте новый язык в объект `translations`
3. Добавьте кнопку в `portfolio.html`:
   ```html
   <button onclick="setLang('new')">NEW</button>
   ```

### Добавить новую секцию:
1. В `portfolio.html` создайте:
   ```html
   <section id="new-section" class="section-animate">
     <p class="section-tag" data-t="secNew">Новая секция</p>
     <!-- Контент -->
   </section>
   ```
2. Отступ > 40px, margin-bottom > 48px
3. Класс `section-animate` для плавного появления

### Добавить новую функцию:
1. Создайте функцию в `modules.js`
2. Добавьте вызов в `initPortfolio()`
3. Используйте в HTML: `onclick="functionName()"`

---

## ✅ Лучшие практики

1. **Все переводы** → `translations.js`
2. **Все стили** → CSS файлы (welcome.css, portfolio.css)
3. **Все скрипты** → Модули (welcome.js, modules.js)
4. **HTML** → Чистая разметка без стилей и скриптов
5. **Используйте `data-t`** для переводимого контента
6. **localStorage** для сохранения пользовательских настроек

---

## 📊 Размеры файлов

| Файл | Строк | Размер |
|------|-------|--------|
| portfolio.css | 800+ | Основные стили |
| portfolio.html | 300+ | Разметка |
| modules.js | 100+ | Логика |
| translations.js | 250+ | Переводы |
| welcome.js | 60+ | Анимации |
| welcome.css | 150+ | Стили приветствия |
| index.html | 50 | Минимум кода |

---

## 🔗 Зависимости

- **Font Awesome 6.0** (CDN)
- Нет npm зависимостей
- Чистый HTML/CSS/JavaScript

---

Проект готов к расширению и модификации! 🚀
