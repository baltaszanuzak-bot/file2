﻿// Navbar / top-bar background change on scroll
window.addEventListener("scroll", function () {
    const nav = document.querySelector(".navbar, .top-bar");
    if (!nav) return;
    if (window.scrollY > 50) {
        nav.style.background = "rgba(0,0,0,0.95)";
    } else {
        nav.style.background = "rgba(0,0,0,0.8)";
    }
});

// ---- AVATAR ----
function getInitials(name) {
    return name.trim().charAt(0).toUpperCase();
}

function checkAuth() {
    const user = localStorage.getItem('cody_user');
    if (user) {
        const loginLink = document.getElementById('loginLink');
        const avatarWrap = document.getElementById('avatarWrap');
        if (loginLink) loginLink.style.display = 'none';
        if (avatarWrap) avatarWrap.style.display = 'block';
        const circle = document.getElementById('avatarCircle');
        if (circle) circle.textContent = getInitials(user);
        const username = document.getElementById('dropUsername');
        if (username) username.textContent = user;
    } else {
        const loginLink = document.getElementById('loginLink');
        const avatarWrap = document.getElementById('avatarWrap');
        if (loginLink) loginLink.style.display = 'inline';
        if (avatarWrap) avatarWrap.style.display = 'none';
    }
}

function toggleDropdown() {
    const dropdown = document.getElementById('avatarDropdown');
    if (dropdown) dropdown.classList.toggle('open');
}

function doLogout() {
    localStorage.removeItem('cody_user');
    checkAuth();
    const dropdown = document.getElementById('avatarDropdown');
    if (dropdown) dropdown.classList.remove('open');
}

// Close dropdown when clicking outside
document.addEventListener('click', function(e) {
    const wrap = document.getElementById('avatarWrap');
    if (wrap && !wrap.contains(e.target)) {
        const dropdown = document.getElementById('avatarDropdown');
        if (dropdown) dropdown.classList.remove('open');
    }
});

checkAuth();

// ============ GLOBAL VARIABLES ============
let lang = 'en';
let dark = true;

// ============ UNIFIED LANGUAGE SYSTEM ============
// Master translation object with all languages and keys
const T = {
    en: {
        nav_login: "Login", nav_about: "About", nav_foundation: "Foundation", nav_learning: "Learning",
        hero_title: "Cody Tech", hero_desc: "Cody Tech is a modern technology platform focused on programming languages, software development, and building a strong developer ecosystem.",
        btn_start: "Start Learning", about_title: "About", about_desc: "Our mission is to create a space where developers grow — from fundamentals to advanced engineering.",
        found_title: "Foundation", card1_title: "Goal: Build the core infrastructure", card1_desc: "Launch of the Cody Tech platform. Structured programming fundamentals",
        card2_title: "Core language tracks:", card2_desc: "JavaScript, HTML, CSS. Hands-on coding challenges. Documentation & real-world examples",
        card3_title: "Ecosystem", card3_desc: "Goal: Build a developer environment. Open-source projects. Collaboration tools. Version control. Community-driven development.",
        ready_title: "Ready to Start?", footer_txt: "Web Development Courses (HTML, CSS, JavaScript).",
        drop_role: "Student", drop_profile: "My Profile", drop_courses: "My Courses", drop_settings: "Settings", drop_logout: "Logout",
        back: "Back to Courses", login: "Login", subtitle: "A quick guide to popular programming languages", title: "Course Page",
        f_all: "All",
        d_html: "The skeleton of every webpage. Defines structure: headings, paragraphs, images, links. It's a markup language, not a programming language.",
        d_css: "The design layer of the web. Controls colors, fonts, layouts and animations. Works alongside HTML to make pages look good.",
        d_js: "The language of the web. Makes pages interactive. With Node.js it runs on servers too. The most widely used language in the world.",
        d_py: "Clean and readable. Go-to language for data science, machine learning and automation. Also great for web backends with Django or Flask.",
        d_php: "Server-side language that powers a huge part of the web, including WordPress. Generates HTML dynamically on the server.",
        d_java: "Robust, object-oriented. Used in enterprise apps and Android. Write once, run anywhere — runs on the JVM cross-platform.",
        d_cpp: "High-performance language used where speed matters. Powers game engines, operating systems and real-world applications.",
        d_sql: "Standard language for databases. Used to create, read, update and delete data. Every developer should know the basics.",
        d_kotlin: "Modern language for Android. More concise and safer than Java. Officially endorsed by Google for Android development.",
        d_swift: "Apple's language for iOS and macOS. Fast, safe and modern. Replaced Objective-C as the main Apple platform language.",
        d_rust: "Systems language focused on safety and performance. Prevents memory bugs at compile time. Used in critical systems.",
        d_ts: "JavaScript with static typing. Catches bugs before they run. Used in large projects and modern frameworks like Angular and Next.js.",
        c_webpages: "Web pages", c_static: "Static sites", c_styling: "Styling", c_anim: "Animations",
        c_resp: "Responsive", c_data: "Data Analysis", c_games: "Game engines", c_report: "Reporting",
        btn_learn: "Start Learning →",
        lv1: "Beginner", lv2: "Easy", lv3: "Moderate", lv4: "Advanced", lv5: "Expert",
        s1_title: "Introduction", s1_intro: "Welcome to this course section.",
        challenge: "Complete the challenge for this section.",
    },
    ru: {
        nav_login: "Войти", nav_about: "О нас", nav_foundation: "Основы", nav_learning: "Обучение",
        hero_title: "Cody Tech", hero_desc: "Cody Tech — современная платформа, сосредоточенная на языках программирования, разработке ПО и создании сильного сообщества разработчиков.",
        btn_start: "Начать обучение", about_title: "О нас", about_desc: "Наша миссия — создать пространство, где разработчики растут от основ до продвинутой инженерии.",
        found_title: "Основы", card1_title: "Цель: Построить базовую инфраструктуру", card1_desc: "Запуск платформы Cody Tech. Структурированные основы программирования",
        card2_title: "Основные языковые треки:", card2_desc: "JavaScript, HTML, CSS. Практические задачи по кодированию. Документация и примеры из реальной жизни",
        card3_title: "Экосистема", card3_desc: "Цель: Построить среду разработчика. Open-source проекты. Инструменты сотрудничества. Контроль версий. Разработка, управляемая сообществом.",
        ready_title: "Готовы начать?", footer_txt: "Курсы веб-разработки (HTML, CSS, JavaScript).",
        drop_role: "Студент", drop_profile: "Мой профиль", drop_courses: "Мои курсы", drop_settings: "Параметры", drop_logout: "Выйти",
        back: "Назад к курсам", login: "Войти", subtitle: "Краткое руководство по популярным языкам программирования", title: "Страница курса",
        f_all: "Все",
        d_html: "Скелет каждой веб-страницы. Определяет структуру: заголовки, абзацы, изображения, ссылки. Язык разметки, не программирования.",
        d_css: "Слой дизайна веба. Управляет цветами, шрифтами, макетами и анимациями. Работает совместно с HTML.",
        d_js: "Язык веба. Делает страницы интерактивными. С Node.js работает и на серверах. Самый популярный язык в мире.",
        d_py: "Чистый и читаемый. Основной язык для науки о данных, машинного обучения и автоматизации. Отлично для бэкенда.",
        d_php: "Серверный язык, на котором работает большая часть веба, включая WordPress. Генерирует HTML на сервере.",
        d_java: "Надёжный и объектно-ориентированный. Используется в корпоративном ПО и Android. Работает на JVM.",
        d_cpp: "Высокопроизводительный язык для задач, где важна скорость. Игровые движки, ОС, встраиваемые системы.",
        d_sql: "Стандартный язык для баз данных. Создание, чтение, обновление и удаление данных. Must-know для каждого.",
        d_kotlin: "Современный язык для Android. Лаконичнее и безопаснее Java. Официально рекомендован Google.",
        d_swift: "Язык Apple для iOS и macOS. Быстрый, безопасный и современный. Заменил Objective-C.",
        d_rust: "Системный язык с фокусом на безопасность. Предотвращает ошибки памяти на этапе компиляции.",
        d_ts: "JavaScript со статической типизацией. Ловит ошибки до запуска. Для крупных проектов и фреймворков.",
        c_webpages: "Веб-страницы", c_static: "Статические сайты", c_styling: "Оформление", c_anim: "Анимации",
        c_resp: "Адаптивность", c_data: "Анализ данных", c_games: "Игровые движки", c_report: "Отчёты",
        btn_learn: "Начать обучение →",
        lv1: "Начинающий", lv2: "Легко", lv3: "Средний", lv4: "Продвинутый", lv5: "Эксперт",
        s1_title: "Введение", s1_intro: "Добро пожаловать в этот раздел курса.",
        challenge: "Выполните задание для этого раздела.",
    },
    kz: {
        nav_login: "Кіру", nav_about: "Біз туралы", nav_foundation: "Негіздер", nav_learning: "Оқыту",
        hero_title: "Cody Tech", hero_desc: "Cody Tech — бағдарламалау тілдеріне, бағдарлама құрылымына және өндіруші қауымдастығын құруға бағытталған заманауи платформа.",
        btn_start: "Оқыту бастау", about_title: "Біз туралы", about_desc: "Біздің миссиялар өндіруштердің негіздерінен озық инженерциялық деңгейге өсетін орын құру.",
        found_title: "Негіздер", card1_title: "Мақсат: Негіздеген инфрақұрылымын құру", card1_desc: "Cody Tech платформасын іске қосу. Бағдарламалаудың құрылымдалған негіздері",
        card2_title: "Негізгі тіл бағыттары:", card2_desc: "JavaScript, HTML, CSS. Практикалық кодтау сынақтары. Құжаттама және нақты әлемдік мысалдар",
        card3_title: "Экожүйе", card3_desc: "Мақсат: Әзірлеу ортасын құру. Ашық бастапқы жобалар. Ынамдастық құралдары. Нұсқа бақылауы. Ынамдастық ұйытқылы өндіріс.",
        ready_title: "Бастауға дайын ба?", footer_txt: "Веб-әзірлеу курстары (HTML, CSS, JavaScript).",
        drop_role: "Студент", drop_profile: "Менің профилім", drop_courses: "Менің курстарым", drop_settings: "Баптаулар", drop_logout: "Шығу",
        back: "Курстарға оралу", login: "Кіру", subtitle: "Танымал бағдарламалау тілдеріне қысқаша нұсқаулық", title: "Курс беті",
        f_all: "Барлығы",
        d_html: "Әр веб-беттің қаңқасы. Құрылымды анықтайды: тақырыптар, абзацтар, суреттер, сілтемелер. Бағдарламалау емес — белгілеу тілі.",
        d_css: "Веб-тің дизайн қабаты. Түстерді, қаріптерді, макеттерді басқарады. HTML-мен бірге жұмыс істейді.",
        d_js: "Веб тілі. Беттерді интерактивті етеді. Node.js арқылы серверлерде де жұмыс істейді.",
        d_py: "Таза және оқылатын. Деректер ғылымы, машиналық оқыту және автоматтандыру үшін негізгі тіл.",
        d_php: "WordPress-ті қосқанда вебтің үлкен бөлігін қуаттандыратын серверлік тіл.",
        d_java: "Сенімді және объектілі-бағытталған. Кәсіпорын ПЖ мен Android қосымшаларында қолданылады.",
        d_cpp: "Жылдамдық маңызды болғанда қолданылатын жоғары өнімді тіл. Ойын қозғалтқыштары мен ОЖ.",
        d_sql: "Дерекқорлар үшін стандартты тіл. Деректерді жасау, оқу, жаңарту және жою.",
        d_kotlin: "Android үшін заманауи тіл. Java-дан қысқа және қауіпсіз. Google ресми ұсынады.",
        d_swift: "iOS және macOS үшін Apple тілі. Жылдам, қауіпсіз және заманауи.",
        d_rust: "Қауіпсіздік пен өнімділікке бағытталған жүйелік тіл. Жад қателерін болдырмайды.",
        d_ts: "Статикалық типтеуі бар JavaScript. Қателерді іске қосылғанға дейін анықтайды.",
        c_webpages: "Веб-беттер", c_static: "Статикалық сайттар", c_styling: "Безендіру", c_anim: "Анимациялар",
        c_resp: "Адаптивтілік", c_data: "Деректер талдауы", c_games: "Ойын қозғалтқыштары", c_report: "Есептілік",
        btn_learn: "Оқуды бастау →",
        lv1: "Бастаушы", lv2: "Оңай", lv3: "Орташа", lv4: "Жоғары", lv5: "Эксперт",
        s1_title: "Кіріспе", s1_intro: "Осы курс бөліміне қош келдіңіз.",
        challenge: "Осы бөлім үшін тапсырманы орындаңыз.",
    }
};

// ============ LANGUAGE & THEME FUNCTIONS ============
function setLang(l, btn) {
    lang = l;
    // Update button states
    document.querySelectorAll('.ctrl-btn').forEach(b => b.classList.remove('active'));
    if (btn) btn.classList.add('active');
    
    // Get translations
    const translations = T[l] || {};
    
    // Update all elements with data-i attribute
    document.querySelectorAll('[data-i]').forEach(el => {
        const key = el.getAttribute('data-i');
        if (translations[key] !== undefined) {
            el.textContent = translations[key];
        }
    });
    
    // Update page title if exists
    if (translations.title && translations.title !== "Course Page" && translations.title !== "Страница курса" && translations.title !== "Курс беті") {
        document.title = translations.title + " — Cody Tech";
    }
}

function doFilter(cat, btn) {
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    if (btn) btn.classList.add('active');
    document.querySelectorAll('.ref-card').forEach(card => {
        const category = card.dataset.cat || '';
        card.classList.toggle('hidden', cat !== 'all' && !category.includes(cat));
    });
}

function toggleTheme() {
    dark = !dark;
    document.body.classList.toggle('light', !dark);
    const btn = document.getElementById('themeBtn');
    if (btn) {
        btn.textContent = dark ? '🌙' : '☀️';
    }
}

// Initialize theme button on load
window.addEventListener('load', function() {
    const themeBtn = document.getElementById('themeBtn');
    if (themeBtn) {
        themeBtn.textContent = dark ? '🌙' : '☀️';
    }
});

// ============ PAGE-SPECIFIC CODE ============

// Modal functionality
const modal = document.getElementById("loginModal");
const openBtn = document.getElementById("openLogin");
const closeBtn = document.querySelector(".close");

if (openBtn) {
    openBtn.onclick = () => {
        if (modal) modal.style.display = "block";
    };
}

if (closeBtn) {
    closeBtn.onclick = () => {
        if (modal) modal.style.display = "none";
    };
}

window.onclick = (e) => {
    if (e.target === modal && modal) {
        modal.style.display = "none";
    }
};

const loginForm = document.getElementById("loginForm");
if (loginForm) {
    loginForm.addEventListener("submit", function(e) {
        e.preventDefault();
        const login = document.getElementById("login").value;
        const pass = document.getElementById("password").value;

        if (login === "admin" && pass === "1234") {
            alert("Вход выполнен!");
            if (modal) modal.style.display = "none";
        } else {
            alert("Неверный логин или пароль");
        }
    });
}



// ============ BURGER MENU ============
function toggleBurger() {
    const nav = document.querySelector('.navbar ul');
    const navControls = document.querySelector('.nav-controls');
    const burger = document.getElementById('burgerBtn');
    if (nav) nav.classList.toggle('open');
    if (navControls) navControls.classList.toggle('nav-open');
    if (burger) burger.classList.toggle('active');
}

// Close burger menu when a nav link is clicked
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.navbar ul a').forEach(link => {
        link.addEventListener('click', function() {
            const nav = document.querySelector('.navbar ul');
            const navControls = document.querySelector('.nav-controls');
            const burger = document.getElementById('burgerBtn');
            if (nav) nav.classList.remove('open');
            if (navControls) navControls.classList.remove('nav-open');
            if (burger) burger.classList.remove('active');
        });
    });
});
